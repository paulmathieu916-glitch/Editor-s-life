# Editor's Life — Android Tycoon

A playable Kotlin + Jetpack Compose starter game.

## Features in this build
- Beginner-to-Legendary XP rank progression
- Editing jobs with coin and XP rewards
- Studio upgrades that improve job payouts
- Fake-editor investigation cases with evidence-based answers
- Reputation and challenge tracking
- ZEYROX VERIFIED certification gate and blue badge
- Local save data using Android SharedPreferences
- Five-screen navigation: Home, Jobs, Detect, Studio, Profile

## Open and run
1. Install Android Studio (with Android SDK 35 and JDK 17).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Run the `app` configuration on an Android emulator or connected device.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Compose BOM 2024.12.01.

## Game balance
The certification currently requires:
- 25,000 XP (Legendary)
- 100,000 coins in the player's balance
- All three major challenges
- 10 successful investigations
- Passing the final certification exam

The exam button appears only when the other requirements are met. The first build includes a scenario-based evidence question; expand it into a larger multi-stage exam before publishing.

## Suggested next milestones
- Add original art, sound effects, music and animations.
- Replace placeholder investigation cases with a larger authored case database.
- Add a proper multi-question final exam.
- Add achievements, daily quests and cloud saves.
- Add automated unit/UI tests and a release signing configuration.
- Review privacy, age rating and store requirements before publishing.

## Notes
This is an offline single-player foundation. It does not connect to Roblox, social media, or external creator accounts. Investigation scenarios are fictional and use in-game evidence only.


## Build a downloadable APK with GitHub Actions

This repository includes `.github/workflows/android-apk.yml`.

1. Create a GitHub repository and upload the contents of this project.
2. Make sure the default branch is named `main` or `master`.
3. Open the repository's **Actions** tab.
4. Select **Build Editor's Life APK** and choose **Run workflow** (or push a commit).
5. Wait for the build to finish successfully.
6. Open the completed workflow run and download the `editors-life-debug-apk` artifact.
7. Extract the downloaded artifact to get `app-debug.apk`, then install it on your Android device.

The workflow builds a debug APK. Android may ask you to allow installation from the browser or file manager you used to download it. Only install APKs you built yourself or trust.

## Important
The APK is not compiled in this workspace. GitHub Actions performs the Android SDK/Gradle build in its hosted runner. The debug APK is suitable for testing; a signed release build and device testing are still needed before public distribution.
