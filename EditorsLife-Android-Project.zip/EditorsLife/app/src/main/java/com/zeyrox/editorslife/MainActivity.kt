package com.zeyrox.editorslife

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF090A10)
private val Panel = Color(0xFF151824)
private val Panel2 = Color(0xFF1D2231)
private val Red = Color(0xFFFF3D55)
private val Blue = Color(0xFF258BFF)
private val Muted = Color(0xFF9BA3B7)
private val Green = Color(0xFF49D69A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = this
            var game by remember { mutableStateOf(GameState.load(context)) }
            var tab by remember { mutableStateOf(GameTab.HOME) }
            fun update(transform: (GameState) -> GameState) {
                game = transform(game).also { it.save(context) }
            }
            EditorLifeApp(
                game = game,
                tab = tab,
                onTab = { tab = it },
                onUpdate = ::update
            )
        }
    }
}

private data class GameState(
    val money: Long = 150,
    val xp: Int = 0,
    val reputation: Int = 0,
    val jobsDone: Int = 0,
    val fakeExposed: Int = 0,
    val setupLevel: Int = 1,
    val softwareLevel: Int = 1,
    val completedChallenges: Set<String> = emptySet(),
    val certified: Boolean = false,
    val finalExamPassed: Boolean = false
) {
    fun save(context: Context) {
        val json = JSONObject().apply {
            put("money", money); put("xp", xp); put("reputation", reputation)
            put("jobsDone", jobsDone); put("fakeExposed", fakeExposed)
            put("setupLevel", setupLevel); put("softwareLevel", softwareLevel)
            put("challenges", JSONArray(completedChallenges.toList()))
            put("certified", certified); put("finalExamPassed", finalExamPassed)
        }
        context.getSharedPreferences("editors_life_save", Context.MODE_PRIVATE)
            .edit().putString("state", json.toString()).apply()
    }

    companion object {
        fun load(context: Context): GameState {
            val raw = context.getSharedPreferences("editors_life_save", Context.MODE_PRIVATE)
                .getString("state", null) ?: return GameState()
            return runCatching {
                val j = JSONObject(raw)
                val challenges = j.optJSONArray("challenges") ?: JSONArray()
                GameState(
                    money = j.optLong("money", 150),
                    xp = j.optInt("xp", 0),
                    reputation = j.optInt("reputation", 0),
                    jobsDone = j.optInt("jobsDone", 0),
                    fakeExposed = j.optInt("fakeExposed", 0),
                    setupLevel = j.optInt("setupLevel", 1),
                    softwareLevel = j.optInt("softwareLevel", 1),
                    completedChallenges = buildSet {
                        for (i in 0 until challenges.length()) add(challenges.getString(i))
                    },
                    certified = j.optBoolean("certified", false),
                    finalExamPassed = j.optBoolean("finalExamPassed", false)
                )
            }.getOrDefault(GameState())
        }
    }
}

private enum class GameTab(val label: String) {
    HOME("Home"), JOBS("Jobs"), DETECT("Detect"), STUDIO("Studio"), PROFILE("Profile")
}

private data class EditingJob(
    val title: String, val brief: String, val reward: Long, val xp: Int, val difficulty: String
)

private val jobs = listOf(
    EditingJob("Creator intro", "Cut a clean 15-second intro with a strong opening.", 120, 55, "Easy"),
    EditingJob("Gaming montage", "Sync transitions to the beat and keep the pacing sharp.", 240, 100, "Medium"),
    EditingJob("Product teaser", "Build a polished promo with captions and color correction.", 420, 175, "Hard"),
    EditingJob("Music video trailer", "Create a cinematic teaser with precise rhythm.", 650, 260, "Expert")
)

private data class FakeCase(
    val creator: String, val clue: String, val options: List<String>, val correct: Int, val explanation: String
)

private val cases = listOf(
    FakeCase(
        "NovaCuts",
        "Two portfolios contain the same unusual transition sequence and identical timing. Which is the strongest evidence?",
        listOf("A matching sequence plus original project timestamps", "They use the same editing app", "Their profile pictures look alike"),
        0,
        "A distinctive matching sequence supported by original project records is meaningful evidence. Similar tools or profile pictures prove nothing."
    ),
    FakeCase(
        "FlashFX",
        "A creator claims an edit is theirs, but the original creator has an earlier public upload and matching project files. What should you do?",
        listOf("Check the source records and report with evidence", "Accuse them immediately without checking", "Copy the edit too"),
        0,
        "Verify dates and source files, then submit a factual report. Avoid public accusations without reliable evidence."
    ),
    FakeCase(
        "PixelRush",
        "Both editors used a popular template. Is that alone proof of theft?",
        listOf("Yes, always", "No, a shared template alone is not proof", "Only if one has more followers"),
        1,
        "Templates are commonly shared. Look for evidence of copied original work, not popularity or assumptions."
    )
)

private val challengeTargets = listOf(
    Triple("First paycheck", "Complete 1 editing job", 1),
    Triple("Growing portfolio", "Complete 10 editing jobs", 10),
    Triple("Truth seeker", "Expose 3 fake editor cases", 3)
)

private fun rankFor(xp: Int): Pair<String, Int> = when {
    xp >= 25000 -> "Legendary" to 25000
    xp >= 12000 -> "Master Editor" to 12000
    xp >= 5000 -> "Professional" to 5000
    xp >= 2000 -> "Advanced Editor" to 2000
    xp >= 500 -> "Junior Editor" to 500
    else -> "Beginner" to 0
}

@Composable
private fun EditorLifeApp(
    game: GameState,
    tab: GameTab,
    onTab: (GameTab) -> Unit,
    onUpdate: ((GameState) -> GameState) -> Unit
) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, secondary = Blue, background = Ink, surface = Panel,
            onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    GameTab.values().forEach { item ->
                        val icon = when (item) {
                            GameTab.HOME -> Icons.Default.Home
                            GameTab.JOBS -> Icons.Default.VideoLibrary
                            GameTab.DETECT -> Icons.Default.Search
                            GameTab.STUDIO -> Icons.Default.Computer
                            GameTab.PROFILE -> Icons.Default.Person
                        }
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { onTab(item) },
                            icon = { Icon(icon, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Red, selectedTextColor = Red,
                                indicatorColor = Red.copy(alpha = .15f),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
            ) {
                Header(game)
                when (tab) {
                    GameTab.HOME -> HomeScreen(game, onTab)
                    GameTab.JOBS -> JobsScreen(game, onUpdate)
                    GameTab.DETECT -> DetectScreen(game, onUpdate)
                    GameTab.STUDIO -> StudioScreen(game, onUpdate)
                    GameTab.PROFILE -> ProfileScreen(game, onUpdate)
                }
            }
        }
    }
}

@Composable
private fun Header(game: GameState) {
    val (rank, _) = rankFor(game.xp)
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("EDITOR'S LIFE", color = Red, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("BUILD YOUR EDITING LEGACY", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("💰 ${game.money}", fontWeight = FontWeight.Bold, color = Green)
            Text(rank, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun HomeScreen(game: GameState, onTab: (GameTab) -> Unit) {
    val (rank, floor) = rankFor(game.xp)
    val next = listOf(500, 2000, 5000, 12000, 25000).firstOrNull { game.xp < it } ?: 25000
    val progress = if (game.xp >= 25000) 1f else
        ((game.xp - floor).toFloat() / (next - floor).coerceAtLeast(1)).coerceIn(0f, 1f)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            CardBox {
                Text("WELCOME BACK, EDITOR", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                Text(rank.uppercase(), fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("${game.xp} XP  •  ${game.reputation} reputation", color = Muted, fontSize = 12.sp)
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Red, trackColor = Panel2)
                Text(if (game.xp >= 25000) "Maximum rank achieved" else "${next - game.xp} XP to next rank", color = Muted, fontSize = 11.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("JOBS", game.jobsDone.toString(), Modifier.weight(1f))
                StatCard("CASES", game.fakeExposed.toString(), Modifier.weight(1f))
                StatCard("SETUP", "Lv. ${game.setupLevel}", Modifier.weight(1f))
            }
        }
        item {
            CardBox {
                Text("YOUR NEXT MOVE", fontWeight = FontWeight.Bold, color = Red)
                Text("Take editing jobs, improve your studio and build a reputation for original work.", color = Muted, fontSize = 13.sp)
                Button(onClick = { onTab(GameTab.JOBS) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("START EDITING")
                }
            }
        }
        item {
            CardBox {
                Text("THE ZEYROX MISSION", color = Blue, fontWeight = FontWeight.Bold)
                Text("Only the most accomplished editors can earn the ZEYROX VERIFIED certification.", fontSize = 13.sp)
                if (game.certified) ZeyroxBadge()
                else Text("Legendary rank • 100,000 coins • all challenges • 10 verified cases • final exam", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun JobsScreen(game: GameState, onUpdate: ((GameState) -> GameState) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            ScreenTitle("EDITING JOBS", "Complete client briefs to earn coins and XP.")
        }
        items(jobs) { job ->
            CardBox {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(job.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(job.difficulty.uppercase(), color = if (job.difficulty == "Expert") Red else Blue, fontSize = 10.sp)
                }
                Text(job.brief, color = Muted, fontSize = 12.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Reward: ${job.reward} coins", color = Green, fontWeight = FontWeight.Bold)
                    Text("+${job.xp} XP", color = Blue, fontWeight = FontWeight.Bold)
                }
                val multiplier = 1.0 + (game.setupLevel - 1) * .10 + (game.softwareLevel - 1) * .08
                val payout = (job.reward * multiplier).toLong()
                Button(
                    onClick = {
                        onUpdate {
                            it.copy(
                                money = it.money + payout,
                                xp = it.xp + job.xp,
                                reputation = it.reputation + 2,
                                jobsDone = it.jobsDone + 1
                            ).completeAutoChallenges()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) { Text("COMPLETE JOB  •  +$payout") }
            }
        }
        item { Text("Payout bonus: ${((game.setupLevel - 1) * 10) + ((game.softwareLevel - 1) * 8)}%", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
private fun DetectScreen(game: GameState, onUpdate: ((GameState) -> GameState) -> Unit) {
    val case = cases[game.fakeExposed % cases.size]
    var answered by remember(game.fakeExposed) { mutableStateOf(false) }
    var selected by remember(game.fakeExposed) { mutableIntStateOf(-1) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScreenTitle("FAKE EDITOR DETECTION", "Investigate carefully. Evidence matters more than assumptions.") }
        item {
            CardBox {
                Text("CASE FILE #${game.fakeExposed + 1}", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(case.creator, fontWeight = FontWeight.Black, fontSize = 22.sp)
                Text(case.clue, color = Muted, fontSize = 13.sp)
                case.options.forEachIndexed { index, option ->
                    OutlinedButton(
                        onClick = { if (!answered) selected = index },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected == index) Blue.copy(alpha = .18f) else Color.Transparent
                        )
                    ) {
                        Text(option, color = Color.White, textAlign = TextAlign.Start)
                    }
                }
                Button(
                    onClick = {
                        if (selected >= 0 && !answered) {
                            answered = true
                            if (selected == case.correct) {
                                onUpdate {
                                    it.copy(
                                        money = it.money + 300,
                                        xp = it.xp + 180,
                                        reputation = it.reputation + 15,
                                        fakeExposed = it.fakeExposed + 1
                                    ).completeAutoChallenges()
                                }
                            } else {
                                onUpdate { it.copy(reputation = (it.reputation - 3).coerceAtLeast(0)) }
                            }
                        }
                    },
                    enabled = selected >= 0 && !answered,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) { Text("SUBMIT INVESTIGATION") }
                if (answered) {
                    val correct = selected == case.correct
                    Text(if (correct) "CASE SOLVED  •  +300 COINS  •  +180 XP" else "NOT ENOUGH EVIDENCE", color = if (correct) Green else Red, fontWeight = FontWeight.Bold)
                    Text(case.explanation, color = Muted, fontSize = 12.sp)
                    Button(onClick = { answered = false; selected = -1 }, modifier = Modifier.fillMaxWidth()) {
                        Text("NEXT CASE")
                    }
                }
            }
        }
        item { Text("Successful investigations: ${game.fakeExposed}", color = Blue, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun StudioScreen(game: GameState, onUpdate: ((GameState) -> GameState) -> Unit) {
    val setupCost = 500L * game.setupLevel
    val softwareCost = 700L * game.softwareLevel
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScreenTitle("YOUR EDITING STUDIO", "Upgrade your equipment to increase job payouts.") }
        item {
            UpgradeCard(
                title = "Editing PC & monitors",
                description = "A faster workstation. +10% job payout per level.",
                level = game.setupLevel, cost = setupCost, canBuy = game.money >= setupCost
            ) {
                onUpdate { it.copy(money = it.money - setupCost, setupLevel = it.setupLevel + 1) }
            }
        }
        item {
            UpgradeCard(
                title = "Professional editing software",
                description = "Unlock a better workflow. +8% job payout per level.",
                level = game.softwareLevel, cost = softwareCost, canBuy = game.money >= softwareCost
            ) {
                onUpdate { it.copy(money = it.money - softwareCost, softwareLevel = it.softwareLevel + 1) }
            }
        }
        item {
            CardBox {
                Text("CURRENT PAYOUT BONUS", color = Blue, fontWeight = FontWeight.Bold)
                Text("${((game.setupLevel - 1) * 10) + ((game.softwareLevel - 1) * 8)}%", fontSize = 30.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun ProfileScreen(game: GameState, onUpdate: ((GameState) -> GameState) -> Unit) {
    val (rank, _) = rankFor(game.xp)
    val allChallengesDone = challengeTargets.all { game.completedChallenges.contains(it.first) }
    val eligible = game.xp >= 25000 && game.money >= 100000 && allChallengesDone && game.fakeExposed >= 10
    var showExam by remember { mutableStateOf(false) }
    var examAnswer by remember { mutableIntStateOf(-1) }
    var examFeedback by remember { mutableStateOf<String?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { ScreenTitle("EDITOR PROFILE", "Your reputation is built through skill and consistency.") }
        item {
            CardBox {
                Text("CURRENT RANK", color = Muted, fontSize = 10.sp)
                Text(rank, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("${game.xp} XP  •  ${game.reputation} reputation", color = Muted)
                Text("${game.money} coins earned balance", color = Green)
            }
        }
        item {
            CardBox {
                Text("MAJOR CHALLENGES", color = Red, fontWeight = FontWeight.Bold)
                challengeTargets.forEach { target ->
                    val done = game.completedChallenges.contains(target.first)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, tint = if (done) Green else Muted)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(target.first, fontWeight = FontWeight.Bold)
                            Text(target.second, color = Muted, fontSize = 11.sp)
                        }
                        Text(if (done) "DONE" else "LOCKED", color = if (done) Green else Muted, fontSize = 10.sp)
                    }
                }
            }
        }
        item {
            CardBox {
                Text("ZEYROX VERIFIED", color = Blue, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text("Certification requirements", color = Muted, fontSize = 12.sp)
                RequirementRow("Legendary rank (25,000 XP)", game.xp >= 25000)
                RequirementRow("100,000 coins in balance", game.money >= 100000)
                RequirementRow("All major challenges", allChallengesDone)
                RequirementRow("10 successful investigations", game.fakeExposed >= 10)
                RequirementRow("Final certification exam", game.finalExamPassed)
                if (game.certified) {
                    ZeyroxBadge()
                    Text("CERTIFICATION UNLOCKED. You are among the best.", color = Green, fontWeight = FontWeight.Bold)
                } else if (eligible) {
                    Button(
                        onClick = { showExam = true; examAnswer = -1; examFeedback = null },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) { Text("TAKE FINAL CERTIFICATION EXAM") }
                } else {
                    Text("Keep improving. Every requirement must be completed.", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { onUpdate { GameState() } },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)
            ) { Icon(Icons.Default.RestartAlt, null); Spacer(Modifier.width(6.dp)); Text("RESET GAME SAVE") }
        }
    }
    if (showExam) {
        AlertDialog(
            onDismissRequest = { showExam = false },
            containerColor = Panel,
            title = { Text("ZEYROX FINAL EXAM", color = Blue, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "A creator reports that their edit was stolen. Two videos look similar, but both creators used the same public template. What is the most responsible next step?",
                        color = Color.White
                    )
                    listOf(
                        "Immediately expose the second creator",
                        "Compare original project evidence, upload history and distinctive copied elements before making a report",
                        "Assume the creator with fewer followers is responsible"
                    ).forEachIndexed { index, answer ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = examAnswer == index, onClick = { examAnswer = index })
                            Text(answer, color = Color.White, fontSize = 12.sp)
                        }
                    }
                    examFeedback?.let { Text(it, color = Red, fontWeight = FontWeight.Bold) }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = examAnswer >= 0,
                    onClick = {
                        if (examAnswer == 1) {
                            onUpdate { it.copy(finalExamPassed = true, certified = true) }
                            showExam = false
                        } else {
                            examFeedback = "Not passed. Review the evidence principles and try again."
                        }
                    }
                ) { Text("SUBMIT ANSWER", color = Blue) }
            },
            dismissButton = {
                TextButton(onClick = { showExam = false }) { Text("CLOSE", color = Muted) }
            }
        )
    }
}

private fun GameState.completeAutoChallenges(): GameState {
    val done = completedChallenges.toMutableSet()
    if (jobsDone >= 1) done.add("First paycheck")
    if (jobsDone >= 10) done.add("Growing portfolio")
    if (fakeExposed >= 3) done.add("Truth seeker")
    return copy(completedChallenges = done)
}

@Composable
private fun RequirementRow(label: String, complete: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (complete) Icons.Default.CheckCircle else Icons.Default.Lock, null, tint = if (complete) Green else Muted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 12.sp, color = if (complete) Color.White else Muted)
    }
}

@Composable
private fun ZeyroxBadge() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.size(86.dp).background(Blue, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("ZEY", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp, letterSpacing = (-1).sp)
                Icon(Icons.Default.Verified, null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(Modifier.padding(top = 8.dp, bottom = 4.dp)) {
        Text(title, color = Red, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value, fontWeight = FontWeight.Black, fontSize = 17.sp)
    }
}

@Composable
private fun UpgradeCard(
    title: String, description: String, level: Int, cost: Long, canBuy: Boolean, onBuy: () -> Unit
) {
    CardBox {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(description, color = Muted, fontSize = 12.sp)
        Text("LEVEL $level", color = Blue, fontWeight = FontWeight.Bold)
        Button(onClick = onBuy, enabled = canBuy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text("UPGRADE  •  $cost COINS")
        }
    }
}
